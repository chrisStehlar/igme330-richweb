export const getRandomElement = (array) => {
    return array[Math.floor(Math.random() * array.length)];
};